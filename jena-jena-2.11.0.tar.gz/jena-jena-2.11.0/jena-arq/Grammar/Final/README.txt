Final-for-spec-publication versions of the grammar.
